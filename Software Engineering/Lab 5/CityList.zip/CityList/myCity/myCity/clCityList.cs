﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace myCity
{
    public class clCityList
    {
        private string _name;
        private int _population;
        private string _countryCode;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int Population
        {
            get { return _population; }
            set { _population = value; }
        }

        public string CountryCode
        {
            get { return _countryCode; }
            set { _countryCode = value; }
        }
        public List<clCityList> GetAll()
        {
            List<clCityList> results = new List<clCityList>();
                    
            MySqlConnection con = new MySqlConnection("server=localhost;User Id=root;password=password;database=world");
            MySqlCommand cmd = new MySqlCommand("" +
                "SELECT Name, Population, CountryCode FROM City WHERE population <= 150000 ORDER BY population DESC LIMIT 10;", con);
            using (con)
            {
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    clCityList newCity = new clCityList();
                    newCity.Name = (string)reader["Name"];
                    newCity.Population = (int)reader["Population"];
                    newCity.CountryCode = (string)reader["CountryCode"];
                    results.Add(newCity);
                }
            }
            con.Close();
            return results;
        }
    }
}
